% scalac BinomialHeap.scala
% scala com.fpdatastruct.binomealheaps.BinomialHeap
4
9
