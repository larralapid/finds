Compile the scala file

% scalac *.scala 

% scala com.fpdatastruct.queue.LeftistHeap
1
2
% scala com.fpdatastruct.queue.Fifo
1
2

