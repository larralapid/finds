import sys
from struct import unpack
from StringIO import StringIO
from time import strftime, gmtime

if len(sys.argv)!=2:
	print "\nUsage: Python BinaryCookieReader.py [Full path to Cookies.binarycookies file] \n"
	print "Example: Python BinaryCookieReader.py C:\Cookies.binarycookies"
	sys.exit(0)
	
FilePath=sys.argv[1]

try:
	binary_file=open(FilePath,'rb')
except IOError as e:
	print 'File Not Found :'+ FilePath
	sys.exit(0)
   
#File Magic String:cook
file_header=binary_file.read(4)                              

if str(file_header)!='cook':
	print "Not a Cookies.binarycookie file"
	sys.exit(0)
	
#Number of pages in the binary file: 4 bytes
num_pages=unpack('>i',binary_file.read(4))[0]   

#Each page size: 4 bytes*number of pages
page_sizes=[]
for np in range(num_pages):
	page_sizes.append(unpack('>i',binary_file.read(4))[0])
	
#Grab individual pages and each page will contain >= one cookie
pages=[]
for ps in page_sizes:
	pages.append(binary_file.read(ps))                      

for page in pages:
	#Converts the string to a file. So that we can use read/write operations easily.
	page=StringIO(page)                                     
	#page header: 4 bytes: Always 00000100
	page.read(4)                                            
	#Number of cookies in each page, first 4 bytes after the page header in every page.
	num_cookies=unpack('<i',page.read(4))[0]                
	
	cookie_offsets=[]
	for nc in range(num_cookies):
		#Every page contains >= one cookie. Fetch cookie starting point from page starting byte
		cookie_offsets.append(unpack('<i',page.read(4))[0]) 
	#end of page header: Always 00000000
	page.read(4)                                            

	cookie=''
	for offset in cookie_offsets:
		#Move the page pointer to the cookie starting point
		page.seek(offset)                                   
		#fetch cookie size
		cookiesize=unpack('<i',page.read(4))[0]             
		#read the complete cookie
		cookie=StringIO(page.read(cookiesize))               
		cookie.read(4)
		#Cookie flags:  1=secure, 4=httponly, 5=secure+httponly
		flags=unpack('<i',cookie.read(4))[0]                
		cookie_flags=''
		if flags==0:
			cookie_flags=''
		elif flags==1:
			cookie_flags='Secure'
		elif flags==4:
			cookie_flags='HttpOnly'
		elif flags==5:
			cookie_flags='Secure; HttpOnly'
		else:
			cookie_flags='Unknown'
			
		cookie.read(4)                                      
		
		#cookie domain offset from cookie starting point
		urloffset=unpack('<i',cookie.read(4))[0]            
		#cookie name offset from cookie starting point
		nameoffset=unpack('<i',cookie.read(4))[0]           
		#cookie path offset from cookie starting point
		pathoffset=unpack('<i',cookie.read(4))[0]           
		#cookie value offset from cookie starting point
		valueoffset=unpack('<i',cookie.read(4))[0]          
		#end of cookie
		endofcookie=cookie.read(8)                          
	
		#Expiry date is in Mac epoch format
		expiry_date_epoch= unpack('<d',cookie.read(8))[0]+978307200          
		expiry_date=strftime("%a, %d %b %Y ",gmtime(expiry_date_epoch))[:-1]
		#Cookies creation time
		create_date_epoch=unpack('<d',cookie.read(8))[0]+978307200           
		create_date=strftime("%a, %d %b %Y ",gmtime(create_date_epoch))[:-1]
		
		#fetch domaain value from url offset
		cookie.seek(urloffset-4)                            
		url=''
		u=cookie.read(1)
		while unpack('<b',u)[0]!=0:
			url=url+str(u)
			u=cookie.read(1)
		#fetch cookie name from name offset		
		cookie.seek(nameoffset-4)                           
		name=''
		n=cookie.read(1)
		while unpack('<b',n)[0]!=0:
			name=name+str(n)
			n=cookie.read(1)
		#fetch cookie path from path offset
		cookie.seek(pathoffset-4)                          
		path=''
		pa=cookie.read(1)
		while unpack('<b',pa)[0]!=0:
			path=path+str(pa)
			pa=cookie.read(1)
		#fetch cookie value from value offset		
		cookie.seek(valueoffset-4)                         
		value=''
		va=cookie.read(1)
		while unpack('<b',va)[0]!=0:
			value=value+str(va)
			va=cookie.read(1)
		
		print 'Cookie : '+name+'='+value+'; domain='+url+'; path='+path+'; '+'expires='+expiry_date+'; '+cookie_flags
		
binary_file.close()