import sys, os
if len(sys.argv)!=2:
	print "\nUsage:AddressBookImageGrabber.py AddressBookImages.txt"
	sys.exit(0)
FilePath=sys.argv[1]
num_files=0

#create ouput directory
output_dir="./AddressBookImages-Output/"
if os.path.exists(output_dir):
	print "AddressBookImages-Output directory already exist. Some files may overwrite."
	print "Press a key to continue or CTRL-C to abort."
	raw_input()
else:
	os.mkdir(output_dir)
#read the input file
try:
	txt_file=open(FilePath,"rb")
except IOError as e:
	print "File Not Found: "+FilePath
records=txt_file.readlines()
#loop through each record in the input file
for r in records:
	if r.startswith("INSERT INTO"):
		#grab filename from ABFullSizeImage table
		name=r.split(",")[1]
		#Convert the file blog in ABFullSizeImage table to ASCII
		filecontent=r.split("X'")[1][:-4].decode("hex")
		filename=output_dir+str(name)+".jpeg"
		print "Writing "+ filename
		#create image file from the decoded blob
		imagefile=open(filename,"wb")
		imagefile.write(filecontent)
		imagefile.close()
		num_files=num_files+1
print "\nTotal "+str(num_files)+" images are extracted"
